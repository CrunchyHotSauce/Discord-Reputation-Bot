const Discord = require("discord.js");
const fs = require("fs");
const moment = require("moment");

const config = require("./settings/config.json");
let points = require("./reputation-module/points.json");
let npoints = require("./reputation-module/npoints.json");

const bot = new Discord.Client();

// bot.commands = new Discord.Collection();
//
// fs.readdir("./commands/", (err, files) => {
//
//   if(err) console.log(err);
//
//   let jsfile = files.filter(f => f.split(".").pop() === "js")
//   if(jsfile.length <= 0){
//     console.log("Couldn't find any commands");
//     return;
//   }
//
//   jsfile.forEach((f, i) => {
//     delete require.cache[require.resolve(`./commands/${f}`)];
//     let props = require(`./commands/${f}`);
//     console.log(`[LOG]${f} loaded!`);
//     bot.commands.set(props.help.name, props);
//
//   });
//
// });

bot.on("ready", () => {
  console.log("Reputation bot ONLINE");
  bot.user.setActivity("Created by Crunchy#0001 | +help");
});

bot.on(`guildMemberAdd`, member => {
   let grole = member.guild.roles.find('name', 'Member');
   member.addRole(grole);
});

bot.on("message", async message => {
  if(message.author.bot) return;
  if(message.channel.type === "dm") return;

  // let prefix = config.prefix;
  // if(!message.content.startsWith(prefix)) return;
  // let commandfile = bot.commands.get(cmd.slice(prefix.length));
  // if (commandfile) commandfile.run(bot, message, args);
  let messageArray = message.content.split(" ");
  let cmd = messageArray[0];
  let args = messageArray.slice(1);

  if(!points[message.author.id + message.guild.id]){
    points[message.author.id + message.guild.id] = {
      points: 0
    };
  }

  if(!npoints[message.author.id + message.guild.id]){
    npoints[message.author.id + message.guild.id] = {
      npoints: 0
    };
  }

if (!points[message.author.id + message.guild.id].lastDaily) points[message.author.id + message.guild.id].lastDaily = 'Not Used';
if (!npoints[message.author.id + message.guild.id].lastDailyR) npoints[message.author.id + message.guild.id].lastDailyR = 'Not Used';

 if(cmd === `+rep`){
  // message.delete()
let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
if(!pUser) return message.reply("You must mention someone!");
if (pUser.id === message.author.id) return message.channel.send(`You cannot add points to yourself! ` + message.author.toString());

if(!points[pUser.id + message.guild.id]){
  points[pUser.id + message.guild.id] = {
    points: 0
  };
}
// if(!args[1]) return message.channel.send(`Please enter a number of points to add! ` + message.author.toString());
// if(isNaN(args[1])) return message.channel.send(`Please enter a number, not words! ` + message.author.toString());

let pCoins = points[pUser.id + message.guild.id].points;
// let number = "1";
if (points[message.author.id + message.guild.id].lastDaily != moment().format('L')) {
  points[message.author.id + message.guild.id].lastDaily = moment().format('L')
  points[message.author.id + message.guild.id].points += 1;
  message.channel.send(`Successfully Added 1 Point to ${pUser}`)
} else {
  message.channel.send(`${message.author.toString()} You already rep'd. You can use it again in ` + moment().endOf('day').fromNow());
}
points[pUser.id + message.guild.id] = {
  points: pCoins + parseInt("1")
};
//
// message.channel.send(`Successfully added ${number} point to ${pUser}`);

fs.writeFile("./reputation-module/points.json", JSON.stringify(points), (err) => {
  if(err) console.log(err)
});
 }
 if(cmd === `-rep`){
   // message.delete()
let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
if(!pUser) return message.reply("You must mention someone!");
if (pUser.id === message.author.id) return message.channel.send(`You cannot remove points from yourself! ` + message.author.toString());

if(!npoints[pUser.id + message.guild.id]){
  npoints[pUser.id + message.guild.id] = {
    npoints: 0
  };
}

// if(!args[1]) return message.channel.send(`Please enter a number of points to remove! ` + message.author.toString());
// if(isNaN(args[1])) return message.channel.send(`Please enter a number, not words! ` + message.author.toString());

// let number = "1";

let pCoins = npoints[pUser.id + message.guild.id].npoints;

if (npoints[message.author.id + message.guild.id].lastDailyR != moment().format('L')) {
  npoints[message.author.id + message.guild.id].lastDailyR = moment().format('L')
  npoints[message.author.id + message.guild.id].npoints += 1;
  message.channel.send(`Successfully Removed 1 Point from ${pUser}`)
} else {
  message.channel.send(`${message.author.toString()} You already rep'd. You can use it again in ` + moment().endOf('day').fromNow());
}
npoints[pUser.id + message.guild.id] = {
  npoints: pCoins - parseInt("1")
};

fs.writeFile("./reputation-module/npoints.json", JSON.stringify(npoints), (err) => {
  if(err) console.log(err)
});
 }

 if(cmd === `-repremove`){
   if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Access Denied.");
   let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
   if(!pUser) return message.reply("You must mention someone!");

   if(!npoints[pUser.id + message.guild.id]){
     npoints[pUser.id + message.guild.id] = {
       npoints: 0
     };
   }

   let nPoints = npoints[pUser.id + message.guild.id].npoints;
   let pCoins = npoints[pUser.id + message.guild.id].npoints;

   let number = args[1];
   if(!number) return message.reply("You must specify a amount to remove!")

   npoints[pUser.id + message.guild.id] = {
     npoints: pCoins - parseInt(number)
   };
   message.channel.send(`Removed ${number} -rep from ${pUser}`);

   fs.writeFile("./reputation-module/npoints.json", JSON.stringify(npoints), (err) => {
     if(err) console.log(err)
   });
 }

  if(cmd === `-repadd`){
    if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Access Denied.");
    let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
    if(!pUser) return message.reply("You must mention someone!");

    if(!npoints[pUser.id + message.guild.id]){
      npoints[pUser.id + message.guild.id] = {
        npoints: 0
      };
    }

    let pCoins = npoints[pUser.id + message.guild.id].npoints;

    let nPoints = npoints[pUser.id + message.guild.id].npoints;

    let number = args[1];
    if(!number) return message.reply("You must specify a amount to remove!")

    npoints[pUser.id + message.guild.id] = {
      npoints: pCoins + parseInt(number)
    };
    message.channel.send(`Added ${number} -rep to ${pUser}`);

    fs.writeFile("./reputation-module/npoints.json", JSON.stringify(npoints), (err) => {
      if(err) console.log(err)
    });
  }


   if(cmd === `+repremove`){
     if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Access Denied.");
     let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
     if(!pUser) return message.reply("You must mention someone!");

     if(!points[pUser.id + message.guild.id]){
       points[pUser.id + message.guild.id] = {
         points: 0
       };
     }

     let nPoints = points[pUser.id + message.guild.id].points;
     let pCoins = points[pUser.id + message.guild.id].points;

     let number = args[1];
     if(!number) return message.reply("You must specify a amount to remove!")

     points[pUser.id + message.guild.id] = {
       points: pCoins - parseInt(number)
     };
     message.channel.send(`Removed ${number} +rep from ${pUser}`);

     fs.writeFile("./reputation-module/points.json", JSON.stringify(points), (err) => {
       if(err) console.log(err)
     });
   }
   if(cmd === `+repadd`){
     if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Access Denied.");
     let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
     if(!pUser) return message.reply("You must mention someone!");

     if(!points[pUser.id + message.guild.id]){
       points[pUser.id + message.guild.id] = {
         points: 0
       };
     }

     let nPoints = points[pUser.id + message.guild.id].points;
     let pCoins = points[pUser.id + message.guild.id].points;

     let number = args[1];
     if(!number) return message.reply("You must specify a amount to remove!")

     points[pUser.id + message.guild.id] = {
       points: pCoins + parseInt(number)
     };
      message.channel.send(`Added ${number} +rep to ${pUser}`);

     fs.writeFile("./reputation-module/points.json", JSON.stringify(points), (err) => {
       if(err) console.log(err)
     });
   }

 if(cmd === `+repcheck`){
   let pUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
   if(!pUser) return message.reply("You must mention someone!");
   if(!points[pUser.id + message.guild.id]){
     points[pUser.id + message.guild.id] = {
       points: 0
     };
   }

   let uPoints = points[pUser.id + message.guild.id].points;

   if(!npoints[pUser.id + message.guild.id]){
     npoints[pUser.id + message.guild.id] = {
       npoints: 0
     };
   }

   let nPoints = npoints[pUser.id + message.guild.id].npoints;

   let sicon = message.guild.iconURL;
   let coinEmbed = new Discord.RichEmbed()
   .setAuthor(`${pUser.user.tag}`, `${pUser.user.avatarURL}`)
   .setColor("#00FF00")
   .setDescription("Displaying USERS Points. ~RB~")
   .setThumbnail(sicon)
   .setTimestamp()
   .setFooter(`${message.author.tag}`,`${message.author.avatarURL}`)
   .addField(`Plus Points:`, uPoints)
   .addField(`Negative Points:`, nPoints)

   message.channel.send(coinEmbed);
 }

if(cmd === `+report`){
  let repUser = message.mentions.users.first();
  if(!repUser) return message.channel.send(`You must mention a user to report! ` + message.author.toString());

  if (repUser.id === message.author.id) return message.channel.send(`You cannot report yourself! ` + message.author.toString());

  let reason = args.slice(1).join(" ");

  message.channel.send(`Successfully Reported ${repUser}!`).then(msg => {msg.delete(3000)});

  const embed = new Discord.RichEmbed()
  .setTitle("Report")
  .setColor("#f46e42")
  .addField("Moderator:", message.author + ` , ID: ${message.author.id}`)
  .addField("Reported User:", `${repUser}, ID: ${repUser.id}`)
  .addField("Reason:", reason)
  .addField("Time:", message.createdAt)

  message.guild.owner.send(embed);

  }

  if(cmd === `+ping`){
    const msg = await message.channel.send(":ping_pong:");
    msg.edit(':ping_pong:Pong! `' + `${msg.createdTimestamp - message.createdTimestamp}` + 'ms`' + ' API Latency `' + `${bot.ping}` + 'ms`')
  }

  if(cmd === `+help`){
    let embed = new Discord.RichEmbed()
    .setTitle("Help...")
    .setTimestamp()
    .setColor("#f45042")
    .addField("Commands:", "+rep, -rep, +repcheck, -repadd, -repremove, +repadd, +repremove, +ping")
    message.channel.send(embed)
  }




});

bot.login(config.token);
